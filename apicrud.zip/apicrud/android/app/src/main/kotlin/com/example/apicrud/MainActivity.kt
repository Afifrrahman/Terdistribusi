package com.example.apicrud

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
